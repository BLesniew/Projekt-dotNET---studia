﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project_NET___studia
{
    /// <summary>
    /// Provides editing task name.
    /// </summary>
    public partial class popupWindowEditTask : Window
    {
        Task taskToEdit;
        MainWindow mainWindow;
        public popupWindowEditTask(MainWindow mainWindowP, Task taskToEditP)
        {
            InitializeComponent();
            mainWindow = mainWindowP;
            taskToEdit = taskToEditP;
        }

        private void ConfirmTaskName(object sender, RoutedEventArgs e)
        {
            taskToEdit.Content = taskNameBox.Text;
            mainWindow.context.SaveChanges();
            mainWindow.tasksContainer.Items.Refresh();
            this.Close();
        }
    }
}
