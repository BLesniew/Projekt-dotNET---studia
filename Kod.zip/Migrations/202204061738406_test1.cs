﻿namespace Project_NET___studia.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class test1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.TasksLists",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Content = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Tasks",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Content = c.String(),
                        myNumber = c.Int(nullable: false),
                        TaskListId = c.Int(nullable: false),
                        TasksList_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.TasksLists", t => t.TasksList_Id)
                .Index(t => t.TasksList_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Tasks", "TasksList_Id", "dbo.TasksLists");
            DropIndex("dbo.Tasks", new[] { "TasksList_Id" });
            DropTable("dbo.Tasks");
            DropTable("dbo.TasksLists");
        }
    }
}
