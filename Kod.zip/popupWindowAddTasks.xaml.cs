﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project_NET___studia
{
    /// <summary>
    /// Interaction logic for "Add task list" popup window.
    /// </summary>
    public partial class popupWindow : Window
    {
        MainWindow mainWidow;
        public popupWindow(MainWindow mainWindowP)
        {
            InitializeComponent();
            mainWidow = mainWindowP;
        }

        /// <summary>
        /// Called when corresponding button is clocked.
        /// </summary>
        private void AddListFromTrello(object sender, RoutedEventArgs e)
        {
            this.Content = new popupWindowTrello(mainWidow,this);
        }

        /// <summary>
        /// Called when corresponding button is clocked.
        /// </summary>
        private void AddListWithName(object sender, RoutedEventArgs e)
        {
            this.Content = new popupWindowName(mainWidow,this);
        }
    }
}
