﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_NET___studia
{
    /// <summary>
    /// Provides adding task list with the name given in box.
    /// </summary>
    public partial class popupWindowName : Page
    {
        MainWindow mainWindow;
        Window parentWindow;
        public popupWindowName(MainWindow mainWindowP, Window parentWindowP)
        {
            InitializeComponent();
            mainWindow = mainWindowP;
            parentWindow = parentWindowP;
        }

        private void ConfirmListName(object sender, RoutedEventArgs e)
        {
            TasksList newTaskList;
            if (listNameBox.Text=="Done")
            {
                newTaskList = new TasksList(listNameBox.Text + "_");
            }
            else
            {
                newTaskList = new TasksList(listNameBox.Text);
            }
            
            mainWindow.taskLists.Add(newTaskList);
            mainWindow.context.TaskLists.Add(newTaskList);
            mainWindow.context.SaveChanges();
            mainWindow.listsContainer.Items.Refresh();
            parentWindow.Close();
        }
    }
}
