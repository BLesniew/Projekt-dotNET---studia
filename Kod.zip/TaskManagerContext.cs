﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace Project_NET___studia
{
    /// <summary>
    /// Task manager database context.
    /// </summary>
    public class TaskManagerContext : DbContext
    {

        public TaskManagerContext() : base("TaskManagerContext")
        {
            Database.SetInitializer(new TaskManagerDbInitializer());
        }

        public DbSet<Task> Tasks { get; set; }
        public DbSet<TasksList> TaskLists { get; set; }
    }

    /// <summary>
    /// Creates example tasks and task lists.
    /// </summary>
    public class TaskManagerDbInitializer : CreateDatabaseIfNotExists<TaskManagerContext>
    {
        protected override void Seed(TaskManagerContext context)
        {
            //base.Seed(context);
            var tasksLists = new List<TasksList> { new TasksList("List1Examle"), new TasksList("List2Example")};
            tasksLists.ForEach(c => context.TaskLists.Add(c));
            context.SaveChanges();

            List<TasksList> tasksList_db = context.TaskLists.ToList();

            var tasks = new List<Task> { new Task("Task1Examle") { TaskListId = tasksList_db[0].Id }, new Task("Task2Examle") { TaskListId = tasksList_db[0].Id }, new Task() { TaskListId = tasksList_db[0].Id }, new Task() { TaskListId = tasksList_db[1].Id } };
            tasks.ForEach(c => context.Tasks.Add(c));
            context.SaveChanges();
        }
    }
}
