﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_NET___studia
{
    /// <summary>
    /// Represents tasks list as its name and Id.
    /// </summary>
    public class TasksList
    {

        public int Id { get; set; }
        public string Content { get; set; }
        

        public TasksList()
        {
            Content = "Name placeholder";
        }

        public TasksList(string content)
        {
            Content = content;
        }

        //NavigationProperties
        public ICollection<Task> Tasks { get; set; }
    }
}
