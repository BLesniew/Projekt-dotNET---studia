﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Http;
using System.Net.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Headers;
using System.Net.Http;

namespace Project_NET___studia
{
    /// <summary>
    /// The page that provides pulling tasks list from trello.
    /// </summary>
    public partial class popupWindowTrello : Page
    {
        HttpClient httpClient;
        MainWindow mainWindow;

        /// <summary>
        /// Window in which this page is viewed.
        /// </summary>
        Window parentWindow;
        public popupWindowTrello(MainWindow mainWindowP, Window parentWindowP)
        {
            InitializeComponent();

            mainWindow = mainWindowP;
            parentWindow = parentWindowP;
            TrelloInit("2f73f51f035f6ee707d47f4dce73f87f","0e545db62c86917ea06f17b51cf94ddd32c7c44ddc15a8de5d793b9ea7c84a51");
            TrelloShowBoards();
        }

        /// <summary>
        /// Initializes connection with Trello API using consumer key and token.
        /// </summary>
        /// <param name="oauth_consumer_key">Consumer key to get from <see href="https://trello.com/app-key">here</see></param>
        /// <param name="oauth_token">Token to get from <see href="https://trello.com/app-key">here</see></param>
        public async void TrelloInit(string oauth_consumer_key, string oauth_token)
        {

            
            var host = Host
             .CreateDefaultBuilder()
             .ConfigureServices((_, services) =>
             {
                 services.AddHttpClient("trello", options =>
                 {
                     options.BaseAddress = new Uri("https://api.trello.com/1/");
                     options.DefaultRequestHeaders.Authorization =
                         new AuthenticationHeaderValue(
                             "OAuth",
                             "oauth_consumer_key=\""+oauth_consumer_key+"\", oauth_token=\""+oauth_token+"\"");
                 });
             })
             .Build();

            var httpClientFactory = host.Services.GetRequiredService<IHttpClientFactory>();
            httpClient = httpClientFactory.CreateClient("trello");

            var boards = await httpClient.GetFromJsonAsync<List<TrelloIdAndName>>($"members/me/boards");
        }

        /// <summary>
        /// Fills item list in popup window with Trello boards.
        /// </summary>
        internal async void TrelloShowBoards()
        {
            var boards = await httpClient.GetFromJsonAsync<List<TrelloIdAndName>>($"members/me/boards");
            trelloItemsList.ItemsSource = boards;
            trelloItemsList.Tag = "Boards";
        }

        /// <summary>
        /// Fills item list in popup window with Trello lists.
        /// </summary>
        internal async void TrelloShowLists(string selectedBoardId)
        {
            var lists = await httpClient.GetFromJsonAsync<List<TrelloIdAndName>>($"boards/{selectedBoardId}/lists");
            var upList = new TrelloIdAndName { Name = ".." };
            lists.Insert(0,upList);

            trelloItemsList.ItemsSource = lists;
            trelloItemsList.Tag = "Lists";
        }

        /// <summary>
        /// Adds selected Trello list to tasks list in main window and context. Closes the popup window.
        /// </summary>
        internal async void AddTrelloTaskList(string selectedListId, string selectedListName)
        {
            var items = await httpClient.GetFromJsonAsync<List<TrelloIdAndName>>($"lists/{selectedListId}/cards");
            TasksList newTaskList = new TasksList(selectedListName);
            Task tmpTask;

            

            mainWindow.taskLists.Add(newTaskList);
            mainWindow.context.TaskLists.Add(newTaskList);
            mainWindow.context.SaveChanges();

            foreach (var item in items)
            {
                tmpTask = new Task() { TaskListId = newTaskList.Id, Content = item.Name };
                mainWindow.context.Tasks.Add(tmpTask);
                mainWindow.tasks.Add(tmpTask);
                //System.Diagnostics.Debug.WriteLine(item.Name);
            }
            mainWindow.context.SaveChanges();

            mainWindow.listsContainer.Items.Refresh();
            parentWindow.Close();
        }

        /// <summary>
        /// Handles double click on any listbox item (board/list/..)
        /// </summary>
        private void HandleDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if((sender as ListBoxItem).Content.ToString()=="..")
            {
                TrelloShowBoards();
            }
            else if(trelloItemsList.Tag=="Boards")
            {
                TrelloShowLists((string)((sender as ListBoxItem).Tag));
            }
            else
            {
                AddTrelloTaskList((sender as ListBoxItem).Tag.ToString(), (sender as ListBoxItem).Content.ToString());
            }

        }
    }
}
