﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_NET___studia
{
    
    /// <summary>
    /// Represents task as its name and Id.
    /// </summary>
    public class Task
    {

        public int Id { get; set; }
        public string Content { get; set; }

        

        public Task()
        {
            Content = "Name placeholder";
        }

        public Task(string content) : this()
        {
            Content = content;
        }

        //Navigation Properties
        public int TaskListId { get; set; }
        public TasksList TasksList { get; set; }

    }
}
