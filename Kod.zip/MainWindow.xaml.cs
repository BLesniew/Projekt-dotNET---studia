﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Http;
using System.Net.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Headers;
using System.Net.Http;

namespace Project_NET___studia
{
    /// <summary>
    /// Class to manage trello boards, lists and cards
    /// </summary>
    /// 
    internal class TrelloIdAndName
    {
        public string Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }

    /// <summary>
    /// Main window class, provides methods to manage tasks and task lists.
    /// </summary>
    public partial class MainWindow : Window
    {
         

        /// <summary>
        /// List of all tasks
        /// </summary>
        public List<Task> tasks = new();

        /// <summary>
        /// List of all task lists.
        /// </summary>
        public List<TasksList> taskLists = new();
        
        /// <summary>
        /// Taks manager database context.
        /// </summary>
        public TaskManagerContext context;

        /// <summary>
        /// Currently viewed task list's Id
        /// </summary>
        public int currentTaskListId;

        /// <summary>
        /// Initializes main window with all important components.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            


            tasksContainer.Items.Clear();
            listsContainer.Items.Clear();
            context = new TaskManagerContext();


            taskLists = context.TaskLists.ToList();
            currentTaskListId = taskLists[0].Id;


            tasks = new List<Task>();
            var allTasks = context.Tasks.ToList();
            foreach (Task task in allTasks)
            {
                if (task.TaskListId == taskLists[0].Id)
                    tasks.Add(task);
            }

            listsContainer.ItemsSource = taskLists;
            tasksContainer.ItemsSource = tasks;
            
        }


        /// <summary>
        /// Called when "Delete" button on task is clicked.
        /// </summary>
        private void DeleteTask(object sender, RoutedEventArgs e)
        {
            foreach(Task task in tasks)
            {
                if (task.Id == Int32.Parse((sender as Button).Tag.ToString()))
                {
                    tasks.Remove(task);
                    context.Tasks.Remove(task);
                    context.SaveChanges();
                    tasksContainer.Items.Refresh();
                    break;
                }
                    
            }
        }

        /// <summary>
        /// Called when "Edit" button on task is clicked.
        /// </summary>
        private void EditTextInTask(object sender, RoutedEventArgs e)
        {
            int thisId = Int32.Parse((sender as Button).Tag.ToString());
            Task tmpTask=null;
            foreach (Task task in tasks)
            {
                if (thisId == task.Id)
                {
                    tmpTask = task;
                    break;
                }
                    
            }
            Window popup = new popupWindowEditTask(this, tmpTask);
            popup.ShowDialog();
        }

        /// <summary>
        /// Called when "Done" button on task is clicked.
        /// </summary>
        private void MarkTaskAsDone(object sender, RoutedEventArgs e)
        {
            int thisId = Int32.Parse((sender as Button).Tag.ToString());

            TasksList doneList = null;
            foreach(TasksList list in taskLists)
            {
                if(list.Content == "Done")
                {
                    doneList = list;
                    break;
                }
            }
            if(doneList == null)
            {
                doneList = new TasksList("Done");
                
                taskLists.Add(doneList);
                listsContainer.Items.Refresh();

                context.TaskLists.Add(doneList);
                context.SaveChanges();
            }
            
            Task tmpTask = null;
            foreach (Task task in tasks)
            {
                if (thisId == task.Id)
                {
                    tmpTask = task;
                    break;
                }
            }
            if(tmpTask.TaskListId != doneList.Id)
            {
                tmpTask.TaskListId = doneList.Id;
                tasks.Remove(tmpTask);
            }
            
            tasksContainer.Items.Refresh();


        }

        /// <summary>
        /// Called when "+" button is clicked - adds new task to currently viewed list.
        /// </summary>
        private void AddTask(object sender, RoutedEventArgs e)
        {
            Task tmpTask = new Task() {TaskListId = currentTaskListId};
            tasks.Add(tmpTask);
            context.Tasks.Add(tmpTask);
            context.SaveChanges();
            tmpTask.Content = "Task" + tmpTask.Id;
            context.SaveChanges();
            tasksContainer.Items.Refresh();
        }

        /// <summary>
        /// Shows tasks in task list when list name is double-clicked.
        /// </summary>
        private void HandleDoubleClick(object sender, MouseButtonEventArgs e)
        {
            currentTaskListId = Int32.Parse((sender as ListBoxItem).Tag.ToString());
            tasks = new List<Task>();
            var allTasks = context.Tasks.ToList();
            foreach (Task task in allTasks)
            {
                if (task.TaskListId == currentTaskListId)
                    tasks.Add(task);
            }

            tasksContainer.ItemsSource = tasks;
            tasksContainer.Items.Refresh();
        }

        /// <summary>
        /// Called when "Add List" button is clicked - opens popup window to add new list.
        /// </summary>
        private void AddList(object sender, RoutedEventArgs e)
        {
            Window popup = new popupWindow(this);
            popup.ShowDialog();
        }

        /// <summary>
        /// Called when "Delete List" button is clicked - deletes currently highlited list if it's not the only list left.
        /// </summary>
        private void DeleteList(object sender, RoutedEventArgs e)
        {
            TasksList listToDelete = listsContainer.SelectedItem as TasksList;
            if (listToDelete != null && taskLists.Count > 1)
            {
                foreach(Task task in tasks)
                {
                    if (task.TaskListId == listToDelete.Id)
                    {
                        context.Tasks.Remove(task);
                    }
                }
                context.SaveChanges();
                if(currentTaskListId == listToDelete.Id)
                {
                    if(currentTaskListId != taskLists[0].Id)
                        currentTaskListId = taskLists[0].Id;
                    else
                        currentTaskListId = taskLists[1].Id;
                    listsContainer.SelectedItem = listsContainer.Items[0];
                    tasks.Clear();
                    var allTasks = context.Tasks.ToList();
                    foreach (Task task in allTasks)
                    {
                        if (task.TaskListId == taskLists[0].Id)
                        {
                            tasks.Add(task);
                        }
                    }
                }
                tasksContainer.Items.Refresh();

                taskLists.Remove(listToDelete);
                context.TaskLists.Remove(listToDelete);
                context.SaveChanges();
                listsContainer.Items.Refresh();
            }
        }
    }

    

    

    
}
